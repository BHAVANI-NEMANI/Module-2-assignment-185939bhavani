import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddMoviesComponent} from './add-movies/add-movies.component';
import {SearchMovieComponent} from './search-movie/search-movie.component';

const routes: Routes = [
  {path:'addMovie',component:AddMoviesComponent},
  {path:'searchMovie',component:SearchMovieComponent}  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
