import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {
  emp: Emp = {
    id:null,
    name:" ",
    salary:null,
    department:" "


  };
  
  constructor() { 
    
  }

  ngOnInit() {
  }

  addEmp(id,name,sal,dept){
    alert( id +"   " +name+ "    " +sal+ "    "+dept);
   
  

   //alert(` ${event.id} ${event.name} ${event.salary} ${event.department}`);
   
   
       // alert(id + " " + name + " " + salary + " " + department);
  }

}
